# Origin

Origin is a programming language designed for hardware orchestration and intelligent control. It provides a clean, high-level syntax for managing everything from simple GPIO logic to complex modular systems and parallel tasking.

Origin is built to bridge the gap between high-level logic and low-level hardware control, making it ideal for robotics, automation, and quick technical prototyping.

## Installation (Windows)

1. **Download** the zip package.
2. **Extract** it to a directory you want to keep it in (e.g., `C:\Origin`).
3. **Right-click** `install_origin.ps1` and choose **Run with PowerShell**.
4. **Restart** your terminal or IDE to update your environment variables.

To verify, run:
```powershell
origin --version
```

## Getting Started

Create a file named `hello.or`:

```origin
# This is a comment
print "Hello, World!"

let name: str = input "Who are you? "
print "Welcome to Origin, " + name
```

Then run it:
```bash
origin hello.or
```

## Key Capabilities

### Hardware Primitives
Origin treats hardware as a first-class citizen. It includes native support for common protocols and components without requiring external libraries:
- **I2C/SPI/UART**: Native syntax for reading and writing to registers.
- **Servos**: Built-in `set servo.angle` commands with automatic 0-180 degree clamping.
- **GPIO**: Simple pin state management.

### Parallel Execution
Multi-tasking is handled via the `parallel` keyword. You can run blocks of code in separate threads without boilerplate thread management:
```origin
parallel {
    move_arm()
    scan_sensor()
}
# Both finish before the program continues
```

### Static Typing & Modules
Origin uses a clean, mandatory typing system for variables (`let x: int = 10`) and a professional module system.
```origin
import math_utils as mu
from hardware import read_pins

let val: float = mu.calculate(read_pins(1))
```

### Binary Builder
You can package your Origin scripts into standalone executables that run on any Windows machine without needing Origin or Python installed:
```bash
origin build script.or
```

## Community & Docs
Full documentation and language reference can be found at [docs-origin.onrender.com](https://docs-origin.onrender.com).
Source code available at [github.com/boblio-max/origin](https://github.com/boblio-max/origin).

