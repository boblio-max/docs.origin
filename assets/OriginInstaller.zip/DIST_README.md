# 🌌 Origin Programming Language

Origin is a high-level, human-centric programming language designed for **intelligent control**, hardware orchestration, and rapid prototyping.

## 🚀 Quick Installation (Windows)

1.  **Download** the Origin package (.zip).
2.  **Extract** all files to a folder of your choice.
3.  **Right-click** `install_origin.ps1` and select **"Run with PowerShell"**.
4.  **Restart** your terminal (Command Prompt, PowerShell, or VS Code).

## 🛠️ Usage

Once installed, you can use Origin from any terminal:

### Run a Script
```bash
origin my_script.or
```

### Build a Standalone EXE
```bash
origin build my_script.or
```

## 📖 Key Features
- **Human-Centric Syntax**: Clean, English-like commands for printing and input.
- **Hardware Native**: Built-in support for I2C, SPI, UART, and Servos.
- **Parallel Processing**: Simple `parallel {}` blocks for multi-tasking.
- **Smart Scoping**: Robust local and global variable management.
- **Modular**: Professional module system with `import` and `as` support.

---
*Origin: Made for Intelligent Control.*
