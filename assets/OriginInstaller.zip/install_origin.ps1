# Origin Installation Script
# This script installs origin.exe to your user profile and adds it to your PATH.

$installDir = "$HOME\.origin\bin"
$exeName = "origin.exe"
$sourcePath = Join-Path $PSScriptRoot $exeName

Write-Host "--- Origin Language Installer ---" -ForegroundColor Cyan

# 1. Check if source exists
if (-not (Test-Path $sourcePath)) {
    Write-Host "Error: Could not find $exeName in this folder." -ForegroundColor Red
    Write-Host "Please make sure you unzipped the package completely before running this."
    Pause<#  #>
    exit
}

# 2. Create install directory
if (-not (Test-Path $installDir)) {
    Write-Host "[*] Creating installation directory: $installDir"
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
}

# 3. Copy binary
Write-Host "[*] Installing Origin to $installDir..."
Copy-Item $sourcePath -Destination $installDir -Force

# 4. Add to PATH (User level)
Write-Host "[*] Adding Origin to your system PATH..."
$currentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($currentPath -notlike "*$installDir*") {
    $newPath = "$currentPath;$installDir"
    [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    Write-Host "[+] Successfully added to PATH!" -ForegroundColor Green
} else {
    Write-Host "[!] Origin is already in your PATH." -ForegroundColor Yellow
}

Write-Host "`n--- Installation Complete! ---" -ForegroundColor Green
Write-Host "You can now open a NEW terminal and type 'origin' to start."
Write-Host "Try running: origin --help"
Pause
